
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='physical_authn_node', executable='fingerprint_node', name='fingerprint_auth_node', output='screen'),
        Node(package='sensing_node', executable='camera_publisher', name='camera_pub_node', output='screen'),
        Node(package='control_node', executable='control_logic', name='controller_node', output='screen'),
        Node(package='container_node', executable='container_health', name='container_monitor_node', output='screen'),
        Node(package='comm_node', executable='dds_secure_comm', name='dds_comm_node', output='screen'),
        Node(package='maintenance_node', executable='swarm_monitor', name='swarm_maintain_node', output='screen'),
            ),
        Node(
            package='mock_gui_node',
            executable='mock_gui_node',
            name='mock_gui_node',
            output='screen'
        )
            ),
        Node(
            package='gui_frontend_node',
            executable='gui_frontend_node',
            name='gui_frontend_node',
            output='screen'
        )
            ),
        Node(
            package='gpio_led_node',
            executable='led_control_node',
            name='gpio_led_node',
            output='screen'
        )
    ])
