
import rclpy  # 匯入 ROS2 函式庫
from rclpy.node import Node
from std_msgs.msg import String

try:
    import RPi.GPIO as GPIO  # 匯入 Raspberry Pi 的 GPIO 控制函式庫
    GPIO.setmode(GPIO.BCM)   # 設定腳位模式為 BCM
    GPIO.setwarnings(False)
    GPIO.setup(18, GPIO.OUT) # 設定 GPIO18 為輸出模式（對應實體 Pin 12）
    RPI_AVAILABLE = True
except ImportError:
    print("⚠️ 非 Raspberry Pi 環境，GPIO 模擬中")
    RPI_AVAILABLE = False

class LEDController(Node):
    def __init__(self):
        super().__init__('gpio_led_node')
        self.subscription = self.create_subscription(String, 'led/cmd', self.led_callback, 10)
        self.get_logger().info("💡 GPIO LED 控制節點已啟動")

    def led_callback(self, msg):
        command = msg.data.strip().lower()
        if command == 'on':
            if RPI_AVAILABLE:
                GPIO.output(18, GPIO.HIGH)
            self.get_logger().info("✅ LED 已打開")
        elif command == 'off':
            if RPI_AVAILABLE:
                GPIO.output(18, GPIO.LOW)
            self.get_logger().info("✅ LED 已關閉")
        else:
            self.get_logger().warn("❌ 未知 LED 指令")

def main():
    rclpy.init()
    node = LEDController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    if RPI_AVAILABLE:
        GPIO.cleanup()

if __name__ == '__main__':
    main()
