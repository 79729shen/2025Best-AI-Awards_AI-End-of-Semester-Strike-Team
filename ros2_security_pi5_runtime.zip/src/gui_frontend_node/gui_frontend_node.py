
import sys  # 系統模組
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout
import cv2  # OpenCV 用於相機錄影
import datetime
import os  # 匯入 PyQt 元件
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from threading import Thread

class GUIFrontend(Node):  # 定義 ROS2 node 節點
    def __init__(self, gui_callback):
        super().__init__('gui_frontend_node')  # 初始化節點
        self.subscription = self.create_subscription(String, 'auth/token', self.token_callback, 10)
        self.token = None
        self.gui_callback = gui_callback  # 註冊 GUI 更新函數

    def token_callback(self, msg):
        self.token = msg.data
        self.get_logger().info(f'🔐 收到 Token: {self.token}')
        if self.token == 'token1234':
            self.gui_callback('✅ 驗證成功，已授權')
        else:
            self.gui_callback('⛔ 驗證失敗，Token 錯誤')

def ros_spin(node):
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

class GUIWindow(QWidget):  # PyQt GUI 視窗類別
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GUI 登入介面")
        self.setGeometry(200, 200, 300, 200)

        self.label = QLabel("點選下方按鈕進行驗證", self)
        self.button = QPushButton("模擬登入", self)
        self.result = QLabel("", self)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.button)
        
        self.led_on_btn = QPushButton("開啟 LED", self)
        self.led_off_btn = QPushButton("關閉 LED", self)
        layout.addWidget(self.led_on_btn)
        layout.addWidget(self.led_off_btn)
        layout.addWidget(self.result)
        self.led_on_btn.clicked.connect(self.led_on)
        self.led_off_btn.clicked.connect(self.led_off)
    
        self.setLayout(layout)

        rclpy.init(args=None)
        self.ros_node = GUIFrontend(self.update_result)
        self.thread = Thread(target=ros_spin, args=(self.ros_node,), daemon=True)
        self.thread.start()

        self.button.clicked.connect(self.simulate_token)

    def simulate_token(self):
        pub = self.ros_node.create_publisher(String, 'auth/token', 10)
        msg = String()
        msg.data = 'token1234'  # 可改為 'badtoken' 測試拒絕
        pub.publish(msg)
        self.result.setText("⏳ 驗證中...")

    
    def led_on(self):
        pub = self.ros_node.create_publisher(String, 'led/cmd', 10)
        msg = String()
        msg.data = 'on'
        pub.publish(msg)

    def led_off(self):
        pub = self.ros_node.create_publisher(String, 'led/cmd', 10)
        msg = String()
        msg.data = 'off'
        pub.publish(msg)

    def update_result(self, text):
        
        self.result.setText(text)
        if "驗證成功" in text:
            self.record_login_video()

    def record_login_video(self):
        cap = cv2.VideoCapture(0)  # 開啟 USB 相機
        if not cap.isOpened():
            self.result.setText("❌ 找不到相機，錄影失敗")
            return
        os.makedirs("/opt/ros2_security_ws/records", exist_ok=True)
        now = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        out = cv2.VideoWriter(f"/opt/ros2_security_ws/records/login_{now}.mp4", cv2.VideoWriter_fourcc(*'mp4v'), 20.0, (640, 480))
        frame_count = 0
        while frame_count < 100:  # 約錄 5 秒
            ret, frame = cap.read()
            if not ret:
                break
            out.write(frame)
            frame_count += 1
        cap.release()
        out.release()
        self.result.setText("🎥 錄影完成，已儲存登入影片")
    

def main():
    app = QApplication(sys.argv)
    win = GUIWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
