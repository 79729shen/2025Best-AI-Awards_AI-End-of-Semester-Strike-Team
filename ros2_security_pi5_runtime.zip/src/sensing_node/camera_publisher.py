
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image

class CameraPublisher(Node):
    def __init__(self):
        super().__init__('camera_pub_node')
        self.publisher_ = self.create_publisher(Image, 'camera/image', 10)
        self.get_logger().info("📷 感測影像資料發佈中...")

def main():
    rclpy.init()
    node = CameraPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
