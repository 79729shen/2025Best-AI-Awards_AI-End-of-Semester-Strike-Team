
import rclpy
from rclpy.node import Node

class ContainerMonitor(Node):
    def __init__(self):
        super().__init__('container_monitor_node')
        self.get_logger().info("🐳 容器監控啟動：模擬容器權限與健康狀態")

def main():
    rclpy.init()
    node = ContainerMonitor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
