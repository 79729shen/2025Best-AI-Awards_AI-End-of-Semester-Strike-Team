
import rclpy
from rclpy.node import Node

class SwarmMonitor(Node):
    def __init__(self):
        super().__init__('swarm_maintain_node')
        self.get_logger().info("🔧 Swarm CLI 管理節點執行中...")

def main():
    rclpy.init()
    node = SwarmMonitor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
