
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

try:
    import RPi.GPIO as GPIO
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(18, GPIO.OUT)
    RPI_AVAILABLE = True
except ImportError:
    print("⚠️ 未在 Raspberry Pi 環境，GPIO 測試將模擬執行")
    RPI_AVAILABLE = False

class GPIOTestNode(Node):
    def __init__(self):
        super().__init__('gpio_test_node')
        self.publisher_ = self.create_publisher(String, 'led/cmd', 10)
        self.timer = self.create_timer(10.0, self.run_test)
        self.get_logger().info("🔍 GPIO 自動測試節點已啟動")

    def run_test(self):
        self.get_logger().info("🔁 發送 LED ON")
        self.send_cmd('on')
        time.sleep(1)
        if RPI_AVAILABLE:
            status = GPIO.input(18)
            self.get_logger().info(f"GPIO18 狀態：{status}（預期為 1）")
        self.get_logger().info("🔁 發送 LED OFF")
        self.send_cmd('off')
        time.sleep(1)
        if RPI_AVAILABLE:
            status = GPIO.input(18)
            self.get_logger().info(f"GPIO18 狀態：{status}（預期為 0）")
        self.get_logger().info("✅ 測試完成")

    def send_cmd(self, state):
        msg = String()
        msg.data = state
        self.publisher_.publish(msg)

def main():
    rclpy.init()
    node = GPIOTestNode()
    rclpy.spin_once(node, timeout_sec=0.1)  # 啟動一次測試即可
    node.destroy_node()
    rclpy.shutdown()
    if RPI_AVAILABLE:
        GPIO.cleanup()

if __name__ == '__main__':
    main()
