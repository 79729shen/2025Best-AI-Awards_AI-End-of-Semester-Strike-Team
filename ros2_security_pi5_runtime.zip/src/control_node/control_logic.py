
import rclpy  # 匯入 ROS2 函式庫
from rclpy.node import Node  # Node 類別是建立 ROS2 節點的基礎
from std_msgs.msg import String  # 使用 String 型別做為接收訊息格式

class ControlLogic(Node):  # 定義名為 ControlLogic 的節點
    def __init__(self):
        super().__init__('controller_node')  # 初始化控制節點名稱
        self.token = None  # 預設無授權 token
        self.subscription = self.create_subscription(String, 'auth/token', self.token_callback, 10)  # 訂閱 Token 訊息
        self.timer = self.create_timer(5.0, self.control_loop)  # 每 5 秒進行一次控制操作模擬
        self.get_logger().info("🧠 控制邏輯節點已啟動")  # 顯示節點啟動資訊

    def token_callback(self, msg):
        self.token = msg.data  # 接收到授權 token
        self.get_logger().info(f'🛡️ Token 已驗證：{self.token}')  # 顯示接收成功

    def control_loop(self):
        if self.token == 'token1234':  # 比對授權 token
            self.get_logger().info('✅ 已授權：執行控制任務')  # 若比對成功，執行任務
        else:
            self.get_logger().warn('⛔ 尚未授權或 Token 錯誤，操作拒絕')  # 若失敗，拒絕執行

def main():
    rclpy.init()
    node = ControlLogic()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
