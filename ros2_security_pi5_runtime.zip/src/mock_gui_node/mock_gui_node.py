
import rclpy  # 匯入 ROS2 函式庫
from rclpy.node import Node
from std_msgs.msg import String
import random

class MockGUI(Node):  # 模擬 GUI 操作介面
    def __init__(self):
        super().__init__('mock_gui_node')
        self.publisher_ = self.create_publisher(String, 'auth/token', 10)
        self.timer = self.create_timer(5.0, self.send_token)
        self.get_logger().info("🖥️ 模擬 GUI 節點已啟動")

    def send_token(self):
        token = 'token1234' if random.random() > 0.5 else 'badtoken'  # 隨機送出正確或錯誤 token
        msg = String()
        msg.data = token
        self.publisher_.publish(msg)
        self.get_logger().info(f'🧪 發送 Token：{token}')

def main():
    rclpy.init()
    node = MockGUI()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
