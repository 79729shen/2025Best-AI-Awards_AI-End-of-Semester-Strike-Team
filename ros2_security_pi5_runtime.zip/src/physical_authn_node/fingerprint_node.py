
import rclpy  # 匯入 ROS2 函式庫
from rclpy.node import Node
from std_msgs.msg import String
import serial
import time

class FingerprintSDKNode(Node):
    def __init__(self):
        super().__init__('fingerprint_sdk_node')
        self.publisher_ = self.create_publisher(String, 'auth/token', 10)  # 發佈 token
        self.uart = serial.Serial('/dev/ttyUSB0', 19200, timeout=1)  # 設定 UART
        self.timer = self.create_timer(5.0, self.scan_fingerprint)  # 每 5 秒輪詢一次
        self.get_logger().info("🔐 指紋模組 UART 串接中...")

    def scan_fingerprint(self):
        self.send_command(self.construct_match_command())  # 傳送比對指令
        time.sleep(0.2)
        resp = self.uart.read_all()
        if self.check_success(resp):
            self.get_logger().info("✅ 指紋比對成功，Token 發送")
            msg = String()
            msg.data = 'token1234'
            self.publisher_.publish(msg)
        else:
            self.get_logger().warn("⛔ 指紋比對失敗")

    def construct_match_command(self):
        return b'\xF5\x0F\x00\x00\x0F\xF5'  # 模擬比對指令

    def send_command(self, cmd):
        self.uart.write(cmd)
        self.get_logger().info(f'📤 傳送指令：{cmd.hex()}')

    def check_success(self, response):
        return response.startswith(b'\xF5\x00')  # 成功回應標頭

def main():
    rclpy.init()
    node = FingerprintSDKNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
