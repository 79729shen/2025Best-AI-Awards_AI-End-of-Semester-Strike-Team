
import rclpy
from rclpy.node import Node

class DDSComm(Node):
    def __init__(self):
        super().__init__('dds_comm_node')
        self.get_logger().info("🌐 DDS 安全通訊模擬節點已啟動")

def main():
    rclpy.init()
    node = DDSComm()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
