# DOCKER_創建pi_LIDAR

### 1. **建立 Docker 網路和 Volume**

假設你需要在容器中使用網路並保存資料，我們會先創建 Docker 網路和 Volume。

```bash
# 建立 Docker 網路
docker network create --driver bridge pi_lidar_bri

# 創建 Volume（這裡用來保存配置或其他資料）
docker volume create pi_lidar_volume

```

### 2. **啟動 Lidar 容器並連接網路和 Volume**

首先，檢查你在主機上指定的路徑 `/home/user/lidar_data` 是否存在。你可以使用以下命令來檢查：

```bash
bash
Copy
ls /home/user/lidar_data

```

如果該目錄不存在，請創建它：

```bash
bash
Copy
mkdir -p /home/user/lidar_data

```

這樣，你就可以確保目錄存在，然後 Docker 才能成功掛載它。

以下命令會啟動一個新的 `pi_lidar` 容器，並將其連接到 `pi_network` 網路和 `pi_lidar_volume` Volume

```bash
docker run -it \
  --device=/dev/ttyUSB1 \
  --name pi_lidar \
  --network pi_lidar_bri \
  -v pi_lidar_volume:/data \
  -v /home/catdo/pi_lidar:/ros2_ws\
  --mount type=bind,source=/home/user/lidar_data,target=/root/lidar_data \
  ros:foxy /bin/bash

```

這樣會創建一個名為 `pi_lidar` 的容器，並且會將 `/dev/ttyUSB0` 設備掛載到容器內。容器會連接到 `pi_network` 網路，並掛載 Volume 以保留數據。

### 3. **進入容器內並安裝必要的套件**

在容器內，你可以安裝必要的 ROS 2 套件。

```bash
# 進入容器
docker exec -it pi_lidar bash

# 更新 apt 資料庫
apt update

# 安裝 SLAM 工具包
apt install ros-foxy-slam-toolbox

# 安裝 RPLidar ROS 介面
apt install ros-foxy-rplidar-ros

# 設定 ROS 2 環境
source /opt/ros/foxy/setup.bash

```

### 4. **運行 RPLidar**

完成安裝後，運行 RPLidar 範例啟動腳本：

```bash
ros2 launch rplidar_ros rplidar.launch.py

```