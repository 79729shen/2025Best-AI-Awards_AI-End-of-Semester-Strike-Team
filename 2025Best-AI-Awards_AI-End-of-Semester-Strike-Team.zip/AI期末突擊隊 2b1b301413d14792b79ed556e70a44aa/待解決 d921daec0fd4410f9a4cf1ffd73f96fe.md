# 待解決

根據錯誤信息，`boson/VidControls.qml` 文件中的某處可能缺少一個閉合的 `}`。我們可以檢查該文件中的代碼，確保所有的 `{` 都有相應的 `}` 與之匹配。

你可以打開 `boson/VidControls.qml` 文件，然後檢查並修正這些語法錯誤。具體步驟如下：

1. 打開 `boson/VidControls.qml` 文件。
2. 檢查第 89 行附近的代碼，確保所有的 `{` 都有對應的 `}`。
3. 如果缺少 `}`，請添加以閉合塊級作用域。

這是一般的做法，如果你不確定如何進行，可以將該部分代碼複製並在此粘貼，我可以幫助你檢查並修復。

[https://github.com/FLIR/Lepton/blob/main/docs/RaspberryPiGuide.md](https://github.com/FLIR/Lepton/blob/main/docs/RaspberryPiGuide.md)

[光達搭小車](%E5%BE%85%E8%A7%A3%E6%B1%BA%20d921daec0fd4410f9a4cf1ffd73f96fe/%E5%85%89%E9%81%94%E6%90%AD%E5%B0%8F%E8%BB%8A%20fd429f7cc5324ca8aaec6e0b985947f7.md)

[https://chtseng.wordpress.com/2021/03/04/使用flir-lepton-3-5製作熱感應儀/](https://chtseng.wordpress.com/2021/03/04/%E4%BD%BF%E7%94%A8flir-lepton-3-5%E8%A3%BD%E4%BD%9C%E7%86%B1%E6%84%9F%E6%87%89%E5%84%80/)