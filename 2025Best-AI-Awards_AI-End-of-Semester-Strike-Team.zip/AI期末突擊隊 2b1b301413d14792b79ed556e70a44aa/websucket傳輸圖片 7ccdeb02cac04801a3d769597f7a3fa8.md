# websucket傳輸圖片

先執行電腦本機端再執行樹梅派端

### 電腦本機端：

192.168.101.XX為我的電腦IP

查法：下cmd：ipconfig

IPv4 位址 . . . . . . . . . . . . 

8765為通訊串接埠，可改，只是兩者要同步，如果發生

RuntimeError: This event loop is already running

解法請看：

[websucket ip被占用](websucket%E5%82%B3%E8%BC%B8%E5%9C%96%E7%89%87%207ccdeb02cac04801a3d769597f7a3fa8/websucket%20ip%E8%A2%AB%E5%8D%A0%E7%94%A8%20f448d0dd53a2407780b81d0fd1c87a9a.md)

```python
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 18:18:15 2024

@author: catdo
"""

import nest_asyncio
import asyncio
import websockets
import cv2
import numpy as np

nest_asyncio.apply()

async def handler(websocket, path):
    async for message in websocket:
        img_data = np.frombuffer(message, dtype=np.uint8)
        frame = cv2.imdecode(img_data, cv2.IMREAD_COLOR)
        cv2.imshow("Received Image", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

async def main():
    start_server = await websockets.serve(handler, "192.168.101.71", 8765)
    await start_server.wait_closed()

asyncio.get_event_loop().run_until_complete(main())
asyncio.get_event_loop().run_forever()

```

### 樹梅派端

```python
import asyncio
import websockets
import cv2

async def send_video():
    uri = "ws://192.168.101.71:8765"
    async with websockets.connect(uri) as websocket:
        camera = cv2.VideoCapture(0)

        while True:
            ret, frame = camera.read()
            _, img_encoded = cv2.imencode('.jpg', frame)
            await websocket.send(img_encoded.tobytes())

        camera.release()

asyncio.get_event_loop().run_until_complete(send_video())

```