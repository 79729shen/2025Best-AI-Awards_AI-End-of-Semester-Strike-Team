# 熱像儀RGB_mapping_溫度

```python
import cv2
import numpy as np

def raw_to_temperature(raw_value, gain='high', background_temp=28.0, compensation_factor=0.5):
    if gain == 'high':
        # High gain range: -10°C to 140°C
        temperature = ((raw_value / 16383.0) * 150.0) / 3.2
        temperature -= 10.0
    else:
        # Low gain range: -10°C to 450°C
        temperature = ((raw_value / 16383.0) * 460.0) - 10.0
    
    # Apply background temperature compensation
    temperature += compensation_factor * (background_temp - 28.0)

    return temperature

def manual_contrast_adjustment(frame, clip_limit=2.0, tile_grid_size=(8, 8)):
    """Manually adjust the contrast of the image to simulate AGC disablement."""
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
    return clahe.apply(frame)

def perform_ffc_simulation(frame):
    """Simulate Flat Field Correction (FFC) by applying a Gaussian blur."""
    return cv2.GaussianBlur(frame, (5, 5), 0)

cap1 = cv2.VideoCapture(0)

if not cap1.isOpened():
    print('Error: Failed to open camera')
    exit()

background_temp = 28.0
compensation_factor = 0.5

while True:
    ret1, frame1 = cap1.read()
    
    if not ret1:
        print('Error: Failed to read frame')
        break

    enlarged_frame = cv2.resize(frame1, (0, 0), fx=2, fy=2)
    gray_frame = cv2.cvtColor(enlarged_frame, cv2.COLOR_BGR2GRAY)
    raw_data = (gray_frame / 255.0) * 16383

    max_temp = -float('inf')
    max_temp_location = (0, 0)
    
    for y in range(enlarged_frame.shape[0]):
        for x in range(enlarged_frame.shape[1]):
            raw_value = raw_data[y, x]
            temp_value = raw_to_temperature(raw_value, gain='high', background_temp=background_temp, compensation_factor=compensation_factor)
            
            if temp_value > max_temp:
                max_temp = temp_value
                max_temp_location = (x, y)

    # Manually adjust contrast to simulate AGC disablement
    adjusted_frame = manual_contrast_adjustment(gray_frame)
    
    # Simulate FFC by applying a Gaussian blur to reduce noise and non-uniformity
    ffc_corrected_frame = perform_ffc_simulation(adjusted_frame)
    
    temp_text = f'MaxT {max_temp:.2f}°C'
    colored_frame = cv2.applyColorMap(ffc_corrected_frame, cv2.COLORMAP_INFERNO)
    cv2.putText(colored_frame, temp_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.25, (255, 255, 255), 1)
    cv2.circle(colored_frame, max_temp_location, 5, (255, 255, 255), 2)
    
    cv2.imshow('Thermal Image', colored_frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap1.release()
cv2.destroyAllWindows()

```