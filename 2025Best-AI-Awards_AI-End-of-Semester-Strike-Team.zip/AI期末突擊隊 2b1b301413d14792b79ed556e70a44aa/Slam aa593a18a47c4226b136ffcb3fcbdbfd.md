# Slam

[https://hackmd.io/@AMR/slam_intro](https://hackmd.io/@AMR/slam_intro)

[https://wiki.ros.org/gmapping](https://wiki.ros.org/gmapping)

[https://www.youtube.com/watch?v=rAJG2U6WwQg](https://www.youtube.com/watch?v=rAJG2U6WwQg)

[ssh進入小車操作](Slam%20aa593a18a47c4226b136ffcb3fcbdbfd/ssh%E9%80%B2%E5%85%A5%E5%B0%8F%E8%BB%8A%E6%93%8D%E4%BD%9C%201b5c6410541b80b3a659e7f4b238fa93.md)

[里程計範例程式](Slam%20aa593a18a47c4226b136ffcb3fcbdbfd/%E9%87%8C%E7%A8%8B%E8%A8%88%E7%AF%84%E4%BE%8B%E7%A8%8B%E5%BC%8F%201b5c6410541b8021b7f1cde3bd7e6781.md)