# yolov8整合sucket

## 本機先執行：

```python
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 18:18:15 2024

@author: catdo
"""

import nest_asyncio
import asyncio
import websockets
import cv2
import numpy as np
from ultralytics import YOLO
from huggingface_hub import hf_hub_download

# 初始化nest_asyncio
nest_asyncio.apply()

# 下載YOLOv8模型
model_path = hf_hub_download(
    repo_id="pitangent-ds/YOLOv8-human-detection-thermal",
    filename="model.pt"
)
model = YOLO(model_path)

async def handler(websocket, path):
    async for message in websocket:
        # 將接收到的影像資料轉換為影像矩陣
        img_data = np.frombuffer(message, dtype=np.uint8)
        frame = cv2.imdecode(img_data, cv2.IMREAD_COLOR)
        
        # 使用YOLOv8進行偵測
        results = model(frame)

        # 繪製偵測結果
        annotated_frame = results[0].plot()

        # 顯示結果
        cv2.imshow("Received Image with Detections", annotated_frame)
        
        # 按 'q' 鍵退出顯示
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

async def main():
    # 設置WebSocket伺服器
    start_server = await websockets.serve(handler, "192.168.108.XX", 8765)
    await start_server.wait_closed()

# 運行WebSocket伺服器
asyncio.get_event_loop().run_until_complete(main())
asyncio.get_event_loop().run_forever()

```

### Pi5再執行：

```python
import asyncio
import websockets
import cv2

async def send_video():
    uri = "ws://192.168.108.71:8765"
    print(f"Attempting to connect to {uri}...")

    try:

        async with websockets.connect(uri, timeout=60) as websocket:
            print("Connected to the WebSocket server successfully.")
            camera = cv2.VideoCapture(2)

            if not camera.isOpened():
                print("Error: Could not open video device.")
                return

            print("Video capture started. Sending video frames...")

            while True:
                ret, frame = camera.read()
                if not ret:
                    print("Error: Failed to capture image.")
                    break

                _, img_encoded = cv2.imencode('.jpg', frame)
                await websocket.send(img_encoded.tobytes())
                print("Frame sent successfully.")

            camera.release()
            print("Video capture stopped.")
    except asyncio.TimeoutError:
        print(f"Error: Connection to {uri} timed out.")
    except websockets.exceptions.ConnectionClosedError as e:
        print(f"Error: Connection closed unexpectedly: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

asyncio.get_event_loop().run_until_complete(send_video())

```

### 本機用pipeline+GPU跑：

```python
pip install websockets opencv-python-headless numpy ultralytics huggingface_hub torch nest_asyncio
```

```python
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 18:18:15 2024

@author: catdo
"""
import nest_asyncio
import asyncio
import websockets
import cv2
import numpy as np
from ultralytics import YOLO
from huggingface_hub import hf_hub_download
import tensorflow as tf
import threading
import queue

# 初始化 nest_asyncio
nest_asyncio.apply()

# 檢查是否有可用的 GPU
physical_devices = tf.config.list_physical_devices('GPU')
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)
    device = "GPU"
else:
    device = "CPU"
print(f"Using device: {device}")

# 下載 YOLOv8 模型
model_path = hf_hub_download(
    repo_id="pitangent-ds/YOLOv8-human-detection-thermal",
    filename="model.pt"
)
model = YOLO(model_path)

# 初始化影像批次隊列和結果隊列
image_batch_queue = queue.Queue(maxsize=10000)
results_queue = queue.Queue(maxsize=10000)
BATCH_SIZE = 4  # 批次大小，可以根據 GPU 能力進行調整

def process_image(message):
    """將接收到的影像數據轉換為影像矩陣"""
    img_data = np.frombuffer(message, dtype=np.uint8)
    frame = cv2.imdecode(img_data, cv2.IMREAD_COLOR)
    return frame

def batch_processor():
    """批量處理影像"""
    while True:
        try:
            batch = []
            for _ in range(BATCH_SIZE):
                frame = image_batch_queue.get()
                if frame is None:
                    break
                batch.append(frame)

            if batch:
                results = model(batch)
                results_queue.put(results)
                print("Batch processed and results queued.")
        except Exception as e:
            print(f"Error in batch_processor: {e}")

def result_processor():
    """處理檢測結果並顯示"""
    while True:
        try:
            results = results_queue.get()
            if results is None:
                break
            for result in results:
                annotated_frame = result.plot()
                cv2.imshow("Received Image with Detections", annotated_frame)
                # 按 'q' 鍵退出顯示
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    results_queue.put(None)  # 結束處理
                    return
            print("Results processed and displayed.")
        except Exception as e:
            print(f"Error in result_processor: {e}")

async def websocket_handler(websocket):
    """處理 WebSocket 傳入的影像數據"""
    try:
        while True:
            message = await websocket.recv()  # 使用 await 獲取數據
            if not message:
                break
            frame = process_image(message)
            image_batch_queue.put(frame)
            print("Frame received and queued.")
    except websockets.exceptions.ConnectionClosedError as e:
        print(f"Connection closed with error: {e}")
    except Exception as e:
        print(f"Error in websocket_handler: {e}")

async def handler(websocket, path):
    await websocket_handler(websocket)

async def main():
    try:
        # 設置 WebSocket 伺服器，增加超時和最大消息大小設置
        print("Starting WebSocket server...")
        start_server = await websockets.serve(
            handler, "192.168.108.71", 8765,
            max_size=10000000,  # 設置最大消息大小
            ping_interval=30,   # 設置 ping 的時間間隔，保持連接活躍
            ping_timeout=600     # 設置 ping 的超時時間
        )
        print("WebSocket server started.")

        # 啟動批量處理和結果顯示的線程
        threading.Thread(target=batch_processor).start()
        threading.Thread(target=result_processor).start()

        await start_server.wait_closed()
    except Exception as e:
        print(f"Error in main: {e}")

# 運行 WebSocket 伺服器
asyncio.get_event_loop().run_until_complete(main())
asyncio.get_event_loop().run_forever()

```

pyqt 版本單視窗測試OK code

```jsx
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 25 18:18:15 2024

@author: catdo
"""

import sys
import nest_asyncio
import asyncio
import websockets
import cv2
import numpy as np
from ultralytics import YOLO
from huggingface_hub import hf_hub_download
import tensorflow as tf
import threading
import queue
from PyQt5.QtCore import pyqtSignal, QThread, QObject, QTimer, Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
from PyQt5.QtGui import QPixmap, QImage

class YOLOWebSocketServer(QObject):
    new_frame = pyqtSignal(np.ndarray)  # Signal to send new frames to the GUI

    def __init__(self, host, port, batch_size=4):
        super().__init__()
        nest_asyncio.apply()

        self.host = host
        self.port = port
        self.batch_size = batch_size

        # Check for available GPU
        physical_devices = tf.config.list_physical_devices('GPU')
        if len(physical_devices) > 0:
            tf.config.experimental.set_memory_growth(physical_devices[0], True)
            self.device = "GPU"
        else:
            self.device = "CPU"
        print(f"Using device: {self.device}")

        # Download YOLOv8 model from Hugging Face Hub
        model_path = hf_hub_download(
            repo_id="pitangent-ds/YOLOv8-human-detection-thermal",
            filename="model.pt"
        )
        self.model = YOLO(model_path)

        # Initialize image and results queues
        self.image_batch_queue = queue.Queue(maxsize=10000)
        self.results_queue = queue.Queue(maxsize=10000)

    def process_image(self, message):
        """Convert received image data to an image matrix."""
        img_data = np.frombuffer(message, dtype=np.uint8)
        frame = cv2.imdecode(img_data, cv2.IMREAD_COLOR)
        return frame

    def batch_processor(self):
        """Process images in batches using YOLO model."""
        while True:
            try:
                batch = []
                for _ in range(self.batch_size):
                    frame = self.image_batch_queue.get()
                    if frame is None:
                        continue
                    batch.append(frame)

                if batch:
                    results = self.model(batch)
                    self.results_queue.put(results)
                    print("Batch processed and results queued.")
            except Exception as e:
                print(f"Error in batch_processor: {e}")

    def result_processor(self):
        """Process detection results and emit signals to update the GUI."""
        while True:
            try:
                results = self.results_queue.get()
                if results is None:
                    continue
                for result in results:
                    annotated_frame = result.plot()
                    self.new_frame.emit(annotated_frame)  # Emit signal with new frame
            except Exception as e:
                print(f"Error in result_processor: {e}")

    async def websocket_handler(self, websocket):
        """Handle incoming image data from WebSocket."""
        try:
            while True:
                message = await websocket.recv()
                if not message:
                    continue
                frame = self.process_image(message)
                self.image_batch_queue.put(frame)
                print("Frame received and queued.")
        except websockets.exceptions.ConnectionClosedError as e:
            print(f"Connection closed with error: {e}")
        except Exception as e:
            print(f"Error in websocket_handler: {e}")

    async def handler(self, websocket, path):
        await self.websocket_handler(websocket)

    async def start_server(self):
        """Start the WebSocket server and processing threads."""
        try:
            print("Starting WebSocket server...")
            start_server = await websockets.serve(
                self.handler, self.host, self.port,
                max_size=10000000, ping_interval=30, ping_timeout=600
            )
            print("WebSocket server started.")

            # Start batch and result processing threads
            threading.Thread(target=self.batch_processor, daemon=True).start()
            threading.Thread(target=self.result_processor, daemon=True).start()

            await start_server.wait_closed()
        except Exception as e:
            print(f"Error in start_server: {e}")

    def run(self):
        """Run the WebSocket server."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.start_server())
        loop.run_forever()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YOLO WebSocket with QGraphicsView")
        self.setGeometry(100, 100, 800, 600)

        # Create QGraphicsView and scene
        self.graphics_view = QGraphicsView(self)
        self.graphics_view.setGeometry(10, 10, 780, 580)
        self.scene = QGraphicsScene(self)
        self.graphics_view.setScene(self.scene)
        self.pixmap_item = QGraphicsPixmapItem()
        self.scene.addItem(self.pixmap_item)

        # Timer to keep the GUI responsive
        self.timer = QTimer(self)
        self.timer.timeout.connect(lambda: None)  # Keep the event loop running
        self.timer.start(50)  # Update interval

        # Initialize server and start in separate thread
        self.server = YOLOWebSocketServer(host="192.168.231.108", port=8765)
        self.server_thread = QThread()
        self.server.moveToThread(self.server_thread)

        # Connect signals
        self.server.new_frame.connect(self.update_image)
        self.server_thread.started.connect(self.server.run)

        # Start the server thread
        self.server_thread.start()

    def update_image(self, frame):
        """Update QGraphicsView with a new frame"""
        height, width, channel = frame.shape
        bytes_per_line = 3 * width
        qimg = QImage(frame.data, width, height, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qimg)
        self.pixmap_item.setPixmap(pixmap)
        self.graphics_view.fitInView(self.pixmap_item, Qt.KeepAspectRatio)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
```