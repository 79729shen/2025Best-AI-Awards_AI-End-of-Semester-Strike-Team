
import time
import serial
import os
import subprocess
import requests
from datetime import datetime

# Configuration
SERIAL_PORT = "/dev/ttyAMA0" if os.path.exists("/dev/ttyAMA0") else "/dev/serial0"
BAUDRATE = 19200
API_URL = "https://example.com/api/fingerprint/log"  # <-- 修改成您的 API
DEVICE_NAME = "ros2-dds-secure"

ACK_SUCCESS = 0x00
CMD_MATCH = 0x0C
CMD_HEAD = 0xF5
CMD_TAIL = 0xF5

def upload_log(status, user_cn="CN=unknown", code=None):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = {
        "timestamp": timestamp,
        "user_id": user_cn,
        "status": status,
        "device": DEVICE_NAME,
        "match_code": code
    }
    try:
        response = requests.post(API_URL, json=payload, timeout=5)
        print(f"[Log] Uploaded: {status} => {response.status_code}")
    except Exception as e:
        print(f"[Log] Failed to upload: {e}")

def tx_rx_command(ser, command_buf, rx_bytes_need, timeout):
    tx_buf = [CMD_HEAD] + command_buf
    checksum = 0
    for byte in command_buf:
        checksum ^= byte
    tx_buf += [checksum, CMD_TAIL]
    ser.reset_input_buffer()
    ser.write(bytes(tx_buf))

    g_rx_buf = []
    t_start = time.time()
    while time.time() - t_start < timeout and len(g_rx_buf) < rx_bytes_need:
        if ser.in_waiting:
            g_rx_buf.extend(ser.read(ser.in_waiting))
    return g_rx_buf

def verify_fingerprint():
    try:
        ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
        print("[UART] Connected to fingerprint module.")
    except Exception as e:
        print(f"[Error] Cannot open serial port: {e}")
        return

    cmd = [CMD_MATCH, 0, 0, 0, 0]
    response = tx_rx_command(ser, cmd, 8, 5)
    ser.close()

    if len(response) == 8 and response[0] == CMD_HEAD and response[-1] == CMD_TAIL:
        user_code = response[4]
        if user_code == ACK_SUCCESS or user_code in (1, 2, 3):
            user_cn = f"CN=User{user_code}"
            print(f"[Auth] Match success for {user_cn}")
            upload_log("success", user_cn, user_code)
            trigger_cert_and_launch(user_cn)
        else:
            print(f"[Auth] Match failed. Code: {user_code}")
            upload_log("fail", "CN=unknown", user_code)
    else:
        print("[Auth] Invalid or timeout response.")
        upload_log("timeout", "CN=unknown")

def trigger_cert_and_launch(cn_name):
    print(f"[Start] Generating cert for {cn_name}...")
    subprocess.run(["python3", "generate_dynamic_cert.py", cn_name])
    subprocess.run(["python3", "generate_xml_policy.py", cn_name])
    subprocess.run(["bash", "start_secure_ros2.sh", cn_name])

if __name__ == "__main__":
    verify_fingerprint()
