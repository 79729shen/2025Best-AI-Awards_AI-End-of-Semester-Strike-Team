
import os
import sys
from xml.etree.ElementTree import Element, SubElement, ElementTree

SECURITY_DIR = "security"
PERMISSIONS_XML = os.path.join(SECURITY_DIR, "permissions.xml")
GOVERNANCE_XML = os.path.join(SECURITY_DIR, "governance.xml")

def create_permissions(cn):
    root = Element("dds")
    permissions = SubElement(root, "permissions")
    grant = SubElement(permissions, "grant", name=f"{cn}_Grant")

    SubElement(grant, "subject_name").text = cn
    validity = SubElement(grant, "validity")
    SubElement(validity, "not_before").text = "2024-01-01T00:00:00"
    SubElement(validity, "not_after").text = "2030-01-01T00:00:00"

    allow = SubElement(grant, "allow_rule")
    SubElement(allow, "domain").text = "0"
    SubElement(allow, "publish").append(Element("topic")).text = "*"
    SubElement(allow, "subscribe").append(Element("topic")).text = "*"
    SubElement(grant, "default").text = "DENY"

    tree = ElementTree(root)
    tree.write(PERMISSIONS_XML)
    print(f"[XML] permissions.xml generated for {cn}")

def create_governance():
    root = Element("dds")
    access = SubElement(root, "access_control")
    governance = SubElement(access, "governance")
    domain_rules = SubElement(governance, "domain_access_rules")
    rule = SubElement(domain_rules, "domain_rule")

    SubElement(rule, "domains").append(Element("id")).text = "0"
    SubElement(rule, "allow_unauthenticated_participants").text = "false"
    SubElement(rule, "enable_join_access_control").text = "true"
    SubElement(rule, "discovery_protection_kind").text = "ENCRYPT"
    SubElement(rule, "liveliness_protection_kind").text = "ENCRYPT"
    SubElement(rule, "rtps_protection_kind").text = "ENCRYPT"

    topic_rule = SubElement(rule, "topic_access_rules").append(Element("topic_rule"))
    SubElement(topic_rule, "topic_expression").text = "*"
    SubElement(topic_rule, "metadata_protection_kind").text = "ENCRYPT"
    SubElement(topic_rule, "data_protection_kind").text = "ENCRYPT"

    tree = ElementTree(root)
    tree.write(GOVERNANCE_XML)
    print("[XML] governance.xml generated")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 generate_xml_policy.py CN=UserX")
        sys.exit(1)

    os.makedirs(SECURITY_DIR, exist_ok=True)
    create_governance()
    create_permissions(sys.argv[1])
