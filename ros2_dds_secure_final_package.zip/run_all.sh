#!/bin/bash

# 一鍵執行：指紋驗證 ➜ 憑證產生 ➜ XML 權限 ➜ ROS2 節點啟動

echo "🔐 啟動指紋驗證流程..."
python3 fingerprint_uart_verify.py
