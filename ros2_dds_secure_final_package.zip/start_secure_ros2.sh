#!/bin/bash

CN=$1
if [ -z "$CN" ]; then
  echo "❌ Usage: ./start_secure_ros2.sh CN=UserX"
  exit 1
fi

SECURITY_DIR=$(pwd)/security
CERTS_DIR=$SECURITY_DIR/certs

export ROS_SECURITY_ENABLE=true
export ROS_SECURITY_STRATEGY=Enforce
export ROS_SECURITY_ROOT_DIRECTORY=$SECURITY_DIR

# Map identity
cp $CERTS_DIR/$CN.cert.pem $SECURITY_DIR/identity_cert.pem
cp $CERTS_DIR/$CN.key.pem $SECURITY_DIR/identity_private_key.pem
cp $SECURITY_DIR/ca.cert.pem $SECURITY_DIR/ca_cert.pem

echo "🔐 Using identity: $CN"
echo "🚀 Launching secure ROS2 node..."

ros2 run ros2_dds_secure ros2_dds_node --ros-args --remap __node:=$CN
