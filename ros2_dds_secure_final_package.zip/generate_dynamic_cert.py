
import os
import subprocess
import sys

SECURITY_DIR = "security"
CERT_DIR = os.path.join(SECURITY_DIR, "certs")
CA_KEY = os.path.join(SECURITY_DIR, "ca.key.pem")
CA_CERT = os.path.join(SECURITY_DIR, "ca.cert.pem")

def generate_cert_for_cn(cn):
    os.makedirs(CERT_DIR, exist_ok=True)
    key_path = os.path.join(CERT_DIR, f"{cn}.key.pem")
    csr_path = os.path.join(CERT_DIR, f"{cn}.csr.pem")
    cert_path = os.path.join(CERT_DIR, f"{cn}.cert.pem")

    print(f"[Cert] Generating key for {cn}...")
    subprocess.run(["openssl", "genrsa", "-out", key_path, "2048"], check=True)

    print(f"[Cert] Creating CSR...")
    subprocess.run(["openssl", "req", "-new", "-key", key_path,
                    "-out", csr_path, "-subj", f"/CN={cn}"], check=True)

    print(f"[Cert] Signing with CA...")
    subprocess.run(["openssl", "x509", "-req", "-in", csr_path,
                    "-CA", CA_CERT, "-CAkey", CA_KEY, "-CAcreateserial",
                    "-out", cert_path, "-days", "3650"], check=True)

    print(f"[Cert] Done for {cn}")
    return cert_path

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 generate_dynamic_cert.py CN=UserX")
        sys.exit(1)
    cn = sys.argv[1]
    generate_cert_for_cn(cn)
