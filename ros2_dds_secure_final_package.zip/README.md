
# ROS2 DDS-Security + 指紋驗證系統整合套件

本系統整合：
1. UART 指紋模組（Waveshare）
2. ROS2 + DDS-Security 加密通訊
3. 自動憑證產生 + 權限控制 XML
4. 指紋驗證後自動上傳紀錄至 API
5. systemd 開機自動驗證與啟動

---

## 📌 安裝前準備
```bash
sudo apt update
sudo apt install python3-lgpio openssl python3-serial
```

## 📦 系統結構
```
.
├── fingerprint_uart_verify.py       # 指紋驗證與啟動控制
├── generate_dynamic_cert.py         # 憑證產生器
├── generate_xml_policy.py           # 權限與加密 XML
├── ros2_dds_node.py                 # ROS2 節點 (pub/sub)
├── start_secure_ros2.sh             # 啟動流程
├── ros2_dds_secure.service          # 開機啟動服務
├── security/
│   ├── ca.key.pem                   # Root CA 金鑰
│   ├── ca.cert.pem                  # Root CA 憑證
│   ├── permissions.xml              # 動態產生
│   └── governance.xml               # 靜態/加密策略
```

---

## ⚡ 指紋模組接腳說明 (TTL UART)

| 指腳 | 功能        | 樹梅派對應 GPIO |
|------|-------------|-----------------|
| VIN  | 3.3V        | 1               |
| GND  | 地線        | 6               |
| RX   | 接樹梅派 TX | GPIO14 (pin 8)  |
| TX   | 接樹梅派 RX | GPIO15 (pin 10) |
| RST  | 控制腳      | GPIO24 (pin 18) |
| WAKE | 輸入腳      | GPIO23 (pin 16) |

---

## ✅ 執行流程

### 測試驗證：
```bash
python3 fingerprint_uart_verify.py
```

### 自動部署 systemd：
```bash
sudo cp ros2_dds_secure.service /etc/systemd/system/
sudo systemctl daemon-reexec
sudo systemctl enable ros2_dds_secure.service
sudo systemctl start ros2_dds_secure.service
```

---

## ☁️ 上傳紀錄 API 格式
```json
{
  "timestamp": "2025-05-03 14:00:00",
  "user_id": "CN=User1",
  "status": "success",
  "device": "ros2-dds-secure",
  "match_code": 0
}
```

請在 `fingerprint_uart_verify.py` 中修改 `API_URL = "..."`

---

## 🔐 DDS-Security 加密方式
- 加密演算法：AES-GCM
- 驗證演算法：SHA-256
- 憑證模式：PKI RSA 2048bit
- 身份驗證與授權由 CN=UserX + permissions.xml 決定
